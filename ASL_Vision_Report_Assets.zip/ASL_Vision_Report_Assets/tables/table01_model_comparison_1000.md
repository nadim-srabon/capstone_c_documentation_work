**Test results of the four architectures on 1,000 signs (12,560 test clips)**

| Model                | Input           |   Params (M) |   Val top-1 |   Test top-1 |   Test top-5 |   Macro P |   Macro R |   Macro F1 |   Weighted F1 |   Best epoch |   CPU latency (ms) |
|:---------------------|:----------------|-------------:|------------:|-------------:|-------------:|----------:|----------:|-----------:|--------------:|-------------:|-------------------:|
| Video Swin-T         | RGB video       |        28.62 |      0.7464 |       0.6678 |       0.8889 |    0.6943 |    0.6693 |     0.6651 |        0.6649 |           25 |             1220   |
| Geometry Transformer | Landmarks       |         1.91 |      0.6752 |       0.5747 |       0.8182 |    0.5982 |    0.5743 |     0.571  |        0.5716 |           47 |                3.2 |
| ST-GCN               | Landmarks       |         1.37 |      0.5844 |       0.4881 |       0.7403 |    0.5129 |    0.4881 |     0.4836 |        0.4842 |           55 |               10.1 |
| R3D-18 Dual-Stream   | RGB + landmarks |        35.28 |      0.3618 |       0.2815 |       0.5514 |    0.316  |    0.2841 |     0.271  |        0.2703 |           40 |              457.1 |
